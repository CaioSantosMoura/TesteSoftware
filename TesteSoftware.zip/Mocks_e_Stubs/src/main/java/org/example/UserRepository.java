package org.example;

public class UserRepository {
    // Simula uma interface para interação com um banco de dados
    public User findUserByUsername(String username) {
        // Normalmente, faria uma busca no banco de dados
        return null;
    }
}
