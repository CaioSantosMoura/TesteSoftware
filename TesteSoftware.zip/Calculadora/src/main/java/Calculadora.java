public class Calculadora {
    public Calculadora(){}
    public static double soma(double a, double b){
        return a + b;
    }
    public static double subtracao(double a, double b){
        return a - b;
    }
    public static double multiplicacao(double a, double b){
        return a * b;
    }
    public static double divisao(double a, double b){
        return a / b;
    }
    public static double potencia(double a, double b){
        return Math.pow(a,b);
    }
}
