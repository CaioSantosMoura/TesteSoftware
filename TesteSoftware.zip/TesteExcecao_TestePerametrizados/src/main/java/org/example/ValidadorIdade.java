package org.example;

public class ValidadorIdade {

    public boolean isMaiorDeIdade(int idade){
        return idade >= 18;
    }
}
