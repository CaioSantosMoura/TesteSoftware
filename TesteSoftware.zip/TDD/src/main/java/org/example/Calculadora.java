package org.example;

public class Calculadora {
    public int soma (int a, int b){
        return a + b; // Implementação básica para fazer o teste passar
    }
}
