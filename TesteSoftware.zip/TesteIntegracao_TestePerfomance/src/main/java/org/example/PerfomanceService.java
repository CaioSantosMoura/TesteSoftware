package org.example;

import java.util.Arrays;

public class PerfomanceService {

    public void sortArray(int[] array){
        Arrays.sort(array);
    }
}
